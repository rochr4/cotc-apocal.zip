#!/usr/bin/env bash

# All contents of a folder it is run inside WILL be chown'ed, chmod'ed and detoxed RECURSIVELY! as a $USER
# copy it to a folder containing only files and folders You wish to modify.

chown -R $USER:$USER $(pwd) && chmod -R u+rw $(pwd) &&
detox -f detoxrc_cotc -s cotc -r $(pwd) &> detox.log && less detox.log
