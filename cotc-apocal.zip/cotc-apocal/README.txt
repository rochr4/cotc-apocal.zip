# All contents of a folder it is run inside WILL be chown'ed, chmod'ed and detoxed RECURSIVELY! as a $USER
# copy it to a folder containing only files and folders You wish to modify.

Tested with 'detox 1.4.5', rest 'info' in other files.

Make it executable: "chmod u+x Chown-chmod-detox_ALL-in-PWD.sh"
Launch with "./Chown-chmod-detox_ALL-in-PWD.sh"

When it's done it will open 'detox.log' in a pager 'less', if it is empty all went ok, leave pager 'less' by pressing 'q'.

extra: FlattenDir-mvToPwd-removeDirs.sh will remove all folders and put all files into current working directory,
	aka. flattening directory tree, same precautions.
